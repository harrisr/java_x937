The release notes can be found here:
http://weblog.ikvm.net/PermaLink.aspx?guid=926e3554-259e-49a6-82fc-459fbd61ac19
